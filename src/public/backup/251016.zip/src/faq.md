# 常见问题解答

## Java版问题解答

## 问题一：进入游戏为什么报错 Failed to verify name!
![FAQ1](/assets/faq/faq-1.png)
Q：请检查您的名称是否正确，请勿使用中文及特殊字符。

## 问题二：为什么显示无法连接服务器？
![FAQ2](/assets/faq/faq-2.png)
Q1：请检查服务器地址是否填写正确，如：mcs.miragemc.top。
Q2：请检查您的网络是否正常，如网络正常请切换服务器线路重试。

## 问题三：注册时为什么显示无效的邮箱？
![FAQ3](/assets/faq/faq-3.png)
Q：请检查您输入的指令是否正确，如：/reg 123456@qq.com
# 一些有用的网站

<Linkcard url="https://zh.minecraft.wiki/" title="Minecraft Wiki" description="欢迎访问中文Wiki为其添砖加瓦，将Minecraft知识分享至全世界！" logo="https://zh.minecraft.wiki/images/Wiki.png?c6c25&format=original"/>

<Linkcard url="https://www.chunkbase.com/apps/seed-map" title="种子地图" description="一个在线地图查看器，可帮助您找到Minecraft种子的的生物群落及其他特征" logo="https://www.chunkbase.com/img/logo.webp"/>

<Linkcard url="https://pcl.ruanmao.net/" title="Plain Craft Launcher2（PCL2官网）" description="Minecraft 启动器 Plain Craft Launcher2" logo="https://pcl.ruanmao.net/files/pcl2.jpg"/>

<Linkcard url="https://mcapks.net/" title="Minecraft 国际版" description="Minecraft国际版 APK下载渠道" logo="https://www.minecraft.net/content/dam/minecraftnet/games/minecraft/logos/Global-Header_MCCB-Logo_300x51.svg"/>
